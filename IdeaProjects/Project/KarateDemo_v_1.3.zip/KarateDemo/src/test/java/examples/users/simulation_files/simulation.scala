package examples.users.simulation_files

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._
import scala.language.postfixOps

class simulation extends Simulation{
	val rest_Test_case_01 = scenario(scenarioName = "rest_Test_case_01").exec(karateFeature("classpath:examples/users/test_cases/perf/rest_Test_case_01.feature"))
	val rest_Test_case_08 = scenario(scenarioName = "rest_Test_case_08").exec(karateFeature("classpath:examples/users/test_cases/perf/rest_Test_case_08.feature"))
	setUp(
		rest_Test_case_01.inject(rampConcurrentUsers(0) to 10 during(5.seconds)),
		rest_Test_case_08.inject(rampConcurrentUsers(0) to 10 during(20.seconds)),
		
	)
}