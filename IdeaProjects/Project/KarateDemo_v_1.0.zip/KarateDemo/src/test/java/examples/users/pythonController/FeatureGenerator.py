import ujson as json
import examples.users.config_url as conf


for k,v in conf.url.items():
    if k == "jsonforkarate":
        featureinputjson = v
    elif k == "testcases":
        testcases = v


#config = configparser.ConfigParser()
#config.read(r'C:\Users\tushar.khushal.lakhe\IdeaProjects\KarateDemo\src\test\java\examples\users\config.ini')
#featureinputjson = config["url"]["jsonforkarate"]
#testcases = config["url"]["testcases"]

json_for_karate = open(featureinputjson)
dict3 = json.load(json_for_karate)


for i in dict3:
    if i["execution_flag"] == "Yes":
        if i["method"] == 'POST' and i["json_payload"] != "None" and i["queue_name"] == None:
            file1 = open(testcases+i["test_case_id"]+".feature", "w")
            file1.write('\nFeature: ' +i["test_case_id"] + ' Post Request\n')
            file1.write('\n\tBackground:\n\t\t * configure report = { showLog: true, showAllSteps: false }\n\t\t')
            file1.write(' * def '+i["test_case_id"]+"_payload" + " = " + str(i["json_payload"]))
            if i["headers"] != None:
                file1.write('\n\t\t * def '+i["test_case_id"]+"_headers"+ " = " + str(i["headers"]))
                file1.write('\n\n\tScenario: POST User Scenario for '+i["test_case_id"])
                file1.write('\n\n\t\t'+'Given url '+'"'+i["url"]+'"')
                file1.write("\n\t\tAnd headers "+i["test_case_id"]+"_headers")
                file1.write("\n\t\tAnd request "+i["test_case_id"]+"_payload\n")
            elif i["headers"] == None:
                file1.write('\n\n\tScenario: POST User Scenario for '+i["test_case_id"])
                file1.write('\n\n\t\t'+'Given url '+'"'+i["url"]+'"')
                file1.write("\n\t\tAnd request "+i["test_case_id"]+"_payload\n")
            file1.write("\t\tWhen method "+str(i["method"])+"\n\t\tThen status "+str(i["status"])+"\n")
            file1.close()

            with open(testcases+i["test_case_id"]+".feature",  'r+') as f:
                file_source = f.read()
                replace_string = file_source.replace(': False',': false').replace(': True',': true')

            with open(testcases+i["test_case_id"]+".feature", "w") as file:
                file.write(replace_string)

        elif i["method"] == 'GET':
            file1 = open(testcases+i["test_case_id"]+".feature", "w")
            file1.write('\nFeature: ' +i["test_case_id"] + ' GET Request\n')
            if i["headers"] != None:
                file1.write('\n\tBackground:\n\t\t * configure report = { showLog: true, showAllSteps: false }\n\t\t')
                file1.write(' * def '+i["test_case_id"]+"_headers"+ " = " + str(i["headers"]))
                file1.write('\n\n\tScenario: GET Request Scenario for '+i["test_case_id"])
                file1.write('\n\n\t\tGiven url '+'"'+i["url"]+'"')
                file1.write("\n\t\tAnd headers "+i["test_case_id"]+"_headers")
            elif i["headers"] == None:
                file1.write('\n\tScenario: GET Request Scenario for '+i["test_case_id"])
                file1.write('\n\n\t\tGiven url '+'"'+i["url"]+'"')
            file1.write("\n\t\tWhen method "+str(i["method"])+"\n\t\tThen status "+str(i["status"])+"\n")

            file1.close()

            with open(testcases+i["test_case_id"]+".feature",  'r+') as f:
                file_source = f.read()
                replace_string = file_source.replace(': False',': false').replace(': True',': true')

            with open(testcases+i["test_case_id"]+".feature", "w") as file:
                file.write(replace_string)

        elif i["method"] == 'POST' and i["json_payload"] != "None" and i["queue_name"] != None and i["headers"] != None:
            file1 = open(testcases+i["test_case_id"]+".feature", "w")
            file1.write('\nFeature: ' +i["test_case_id"] + ' Queue message request\n')
            file1.write('\n\tBackground:\n\t\t * configure report = { showLog: true, showAllSteps: false }\n\t\t')
            file1.write(' * def '+"queueUtils" + " = " + "Java.type('examples.users.queueUtils')\n\t\t")
            file1.write(' * def '+'queueRequestBody = ("'+str(i["json_payload"])+'")')
            if i["headers"] != None:
                for k, v in eval(i["headers"]).items():
                    file1.write("\n\t\t * def "+k+" = '"+v+"'")
            file1.write("\n\t\t * def connectionUrl = '"+i["url"]+"'")
            file1.write("\n\t\t * def delay =  20")
            file1.write('\n\n\tScenario: Message Queue Scenario for '+i["test_case_id"])
            file1.write("\n\n\t\tGiven queueUtils.createConnection(connectionUrl, username, password)")
            file1.write("\n\t\tWhen queueUtils.send('"+i["queue_name"]+"'" +",queueRequestBody, delay)")
            file1.write("\n\t\tThen print 'Message successfully posted on queue: "+i["queue_name"]+" !!!'")
            file1.close()

            with open(testcases+i["test_case_id"]+".feature",  'r+') as f:
                file_source = f.read()
                replace_string = file_source.replace(': False',': false').replace(': True',': true')

            with open(testcases+i["test_case_id"]+".feature", "w") as file:
                file.write(replace_string)
