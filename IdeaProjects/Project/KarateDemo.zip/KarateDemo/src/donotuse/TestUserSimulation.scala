package examples.users
import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._
import scala.language.postfixOps


class TestUserSimulation extends Simulation {
  val getUser = scenario(scenarioName = "postCall").exec(karateFeature("classpath:examples/users/test_cases/*.feature"))
  //val jsonString = os.read(os.pwd/"src"/"test"/"java"/"examples"/"inputfiles"/"param.json")
  //val data = ujson.read(jsonString)
  //print(jsonString)
  //print(data)
  setUp(
    getUser.inject(rampUsers(users = 1) during(1 seconds))
  )
}
