package examples.users.donotuse;

import com.intuit.karate.junit5.Karate;

public class runner {
     @Karate.Test
        Karate testUsers() {
            return Karate.run("../users/test_cases/").relativeTo(getClass());
        }
}
