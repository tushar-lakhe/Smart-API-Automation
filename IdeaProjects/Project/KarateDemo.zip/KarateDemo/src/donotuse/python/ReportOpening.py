import glob
import os
import webbrowser

for f in glob.glob( r'C:\Users\tushar.khushal.lakhe\IdeaProjects\KarateDemo\target\gatling\*'):
    report = (os.path.split(f)[-1])

filepath =os.path.join('C:/Users/tushar.khushal.lakhe/IdeaProjects/KarateDemo/target/gatling/',report,'index.html')
webbrowser.open_new_tab(filepath)


