import json
import openpyxl as pd

# read json
json_data = open("jsondataforPython.json")
data = json.load(json_data)

xl = pd.load_workbook("dataforjson.xlsx")
ws = xl['Data']
data_list = {}
final_dict = {}
first_row = []

for col in range(1, ws.max_column+1):
    first_row.append(ws.cell(row=1, column=col).value)
excel_list = []

for row in range(2, ws.max_row+1):
    elm = {}
    for col in range(1, ws.max_column+1):
        elm[first_row[col-1]]=ws.cell(row=row,column=col).value
    excel_list.append(elm)
print("data from excel file",excel_list)

for key1, value1 in zip(data, data.items()):
    final_dict[key1] = dict([value1])

dict3 = []
#print("Json file ",final_dict)


for k, v in final_dict.items():
    for keys in excel_list:
        #if keys == data_list.get(keys[1]):
            if keys["test_case_id"] == k:
 #               print(keys|v)
                dict3.append(keys|v)



print("final data",dict3)

with open("karate_src.json", "w", encoding="utf-8") as writeJsonfile:
     json.dump(dict3, writeJsonfile, indent=4)




