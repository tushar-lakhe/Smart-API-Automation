import json

json_for_karate = open("karate_src.json")
dict3 = json.load(json_for_karate)

print(dict3)

list = []

for i in dict3:
    file1 = open("../test_cases/"+i["test_case_id"]+".feature", "w")
    file1.write('\nFeature: ' +i["test_case_id"] + ' Post Request\n\t'+'Scenario: POST User Scenario for '+i["test_case_id"] +'\n\n\t\t'+'Given url '+'"'+i["url"]+'"')
    if i["headers"] != None:
        file1.write("\n\t\tAnd headers "+str(i["headers"])+"\n\t\tAnd request "+str(i[i["test_case_id"]])+"\n")
    elif i["headers"] == None:
        file1.write("\n\t\tAnd request "+str(i[i["test_case_id"]])+"\n")
    file1.write("\t\tWhen method "+str(i["method"])+"\n\t\tThen status "+str(i["status"])+"\n")
    file1.write("\t\tAnd print response \n\n")

    file1.close()

    with open("../test_cases/"+i["test_case_id"]+".feature",  'r+') as f:
        file_source = f.read()
        replace_string = file_source.replace(': False',': false').replace(': True',': true')

    with open("../test_cases/"+i["test_case_id"]+".feature", "w") as file:
        file.write(replace_string)