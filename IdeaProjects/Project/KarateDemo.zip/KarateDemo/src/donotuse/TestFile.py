from json import *

jsonpayload = r"C:/Users/tushar.khushal.lakhe/IdeaProjects/KarateDemo/src/test/java/examples/users/inputData/jsonPayload.json"
json_data = open(jsonpayload)
data = json.load(json_data)

print(data)