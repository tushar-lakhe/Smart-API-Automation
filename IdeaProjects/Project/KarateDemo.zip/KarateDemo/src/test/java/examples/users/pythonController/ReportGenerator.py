import glob
import os
import webbrowser
import configparser
import shutil
import errno
import datetime

config = configparser.ConfigParser()
config.read(r"C:\Users\tushar.khushal.lakhe\IdeaProjects\KarateDemo\src\test\java\examples\users\config.ini")

report = config["url"]["cucumber_report"]
testcases = config["url"]["testcases"]
historytestcases = config["url"]["history_testcases"]
historyreports = config["url"]["history_report"]

now = datetime.datetime.now()
timestamp = str(now.strftime("%Y%m%d_%H%M%S"))


webbrowser.open_new_tab(report)

# testcases moving and deleting

source_testcases = testcases
destination = os.path.join(historytestcases,timestamp)
shutil.copytree(testcases, destination)

dir = testcases
for files in os.listdir(dir):
    path = os.path.join(dir, files)
    try:
        shutil.rmtree(path)
    except OSError:
        os.remove(path)


# report moving

source_report = r"C:/Users/tushar.khushal.lakhe/IdeaProjects/KarateDemo/target/cucumber-html-reports"
destination_report = os.path.join(historyreports,timestamp+"/")

print(source_report)
print(destination_report)


shutil.copytree(source_report, destination_report)


