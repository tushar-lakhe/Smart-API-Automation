import ujson as json
import configparser

config = configparser.ConfigParser()
config.read(r'C:\Users\tushar.khushal.lakhe\IdeaProjects\KarateDemo\src\test\java\examples\users\config.ini')
featureinputjson = config["url"]["jsonforkarate"]
testcases = config["url"]["testcases"]

json_for_karate = open(featureinputjson)
dict3 = json.load(json_for_karate)

#print(dict3)



for i in dict3:
    if i["execution_flag"] == "Yes":
        if i["method"] == 'POST' and i["json_payload"] != "None":
            file1 = open(testcases+i["test_case_id"]+".feature", "w")
            file1.write('\nFeature: ' +i["test_case_id"] + ' Post Request\n\t'+'Scenario: POST User Scenario for '+i["test_case_id"] +'\n\n\t\t'+'Given url '+'"'+i["url"]+'"')
            if i["headers"] != None:
                file1.write("\n\t\tAnd headers "+str(i["headers"])+"\n\t\tAnd request "+str(i["json_payload"])+"\n")
            elif i["headers"] == None:
                file1.write("\n\t\tAnd request "+str(i["json_payload"])+"\n")
            file1.write("\t\tWhen method "+str(i["method"])+"\n\t\tThen status "+str(i["status"])+"\n")
            file1.write("\t\tAnd print response \n\n")

            file1.close()

            with open(testcases+i["test_case_id"]+".feature",  'r+') as f:
                file_source = f.read()
                replace_string = file_source.replace(': False',': false').replace(': True',': true')

            with open(testcases+i["test_case_id"]+".feature", "w") as file:
                file.write(replace_string)
        elif i["method"] == 'GET':
            file1 = open(testcases+i["test_case_id"]+".feature", "w")
            file1.write('\nFeature: ' +i["test_case_id"] + ' GET Request\n\t'+'Scenario: GET Request Scenario for '+i["test_case_id"] +'\n\n\t\t'+'Given url '+'"'+i["url"]+'"')
            if i["headers"] != None:
                file1.write("\n\t\tAnd headers "+str(i["headers"])+"\n")
                file1.write("\t\tWhen method "+str(i["method"])+"\n\t\tThen status "+str(i["status"])+"\n")
                file1.write("\t\tAnd print response \n\n")
            elif i["headers"] == None:
                file1.write("\n\t\tWhen method "+str(i["method"])+"\n\t\tThen status "+str(i["status"])+"\n")
                file1.write("\t\tAnd print response \n\n")

            file1.close()

            with open(testcases+i["test_case_id"]+".feature",  'r+') as f:
                file_source = f.read()
                replace_string = file_source.replace(': False',': false').replace(': True',': true')

            with open(testcases+i["test_case_id"]+".feature", "w") as file:
                file.write(replace_string)
